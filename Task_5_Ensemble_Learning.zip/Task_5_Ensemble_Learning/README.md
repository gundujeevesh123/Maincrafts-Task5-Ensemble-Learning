# Task 5 — Ensemble Learning (Breast Cancer Wisconsin)

Internship submission for **Maincrafts Technology — Artificial Intelligence
& Machine Learning · Task 5**.

**Author:** Gundu Jeevesh Laahiri
**Dataset:** `sklearn.datasets.load_breast_cancer` (Breast Cancer Wisconsin
Diagnostic — 569 samples, 30 features, 2 classes).

---

## 1. Project overview

The notebook builds a complete, reproducible classification pipeline that:

1. Loads and inspects the dataset and verifies the target mapping
   (`0 = malignant`, `1 = benign`).
2. Creates an 80/20 stratified train/test split (`random_state=42`).
3. Trains a **Logistic Regression** baseline inside a `StandardScaler →
   LogisticRegression` scikit-learn `Pipeline`.
4. Trains a **Random Forest** (defaults, `random_state=42`).
5. Trains a **Gradient Boosting** classifier (defaults, `random_state=42`).
6. Tunes the Random Forest with **`GridSearchCV`** over 36 configurations
   using 5-fold stratified cross-validation and a malignant-F1 scorer
   (`make_scorer(f1_score, pos_label=0)`).
7. Evaluates every model on the held-out test set under the same metric
   definitions.
8. Produces visualisations (class distribution, confusion matrix, ROC
   curves, feature importance, CV comparison) and exports CSV/JSON
   artifacts.
9. Selects a final model with an explicitly stated primary criterion and
   discusses the trade-offs honestly.

**Positive-class convention.** Because this is a medical-screening dataset,
precision / recall / F1 are reported for the **malignant** class
(`pos_label=0`) and `GridSearchCV` is scored on malignant F1. Accuracy and
ROC-AUC are label-symmetric. A column labelled "Malignant Recall" is
included so the clinically important number is unambiguous.

---

## 2. Folder structure

```
Task_5_Ensemble_Learning/
├── Task_5_Ensemble_Learning.ipynb     # main deliverable (executed notebook)
├── Task_5_Ensemble_Learning_Report.pdf# 3-page project report
├── README.md
├── requirements.txt
├── environment_info.txt
├── pipeline.py                        # same pipeline as .py (CLI re-run)
├── figures/
│   ├── class_distribution.png
│   ├── confusion_matrix.png
│   ├── roc_curves.png
│   ├── feature_importance.png
│   └── cv_comparison.png
└── results/
    ├── model_comparison.csv
    ├── random_forest_cv_results.csv
    ├── best_parameters.json
    └── final_selection.json
```

---

## 3. Environment requirements

Developed with Python **3.12** and these library versions (full list in
`environment_info.txt`):

| Library       | Version |
|---------------|---------|
| numpy         | 2.4.4   |
| pandas        | 3.0.2   |
| scikit-learn  | 1.8.0   |
| matplotlib    | 3.10.8  |
| seaborn       | 0.13.2  |

The code is pinned to the scikit-learn API in `1.4+` and should run with
any `scikit-learn ≥ 1.4`, `pandas ≥ 2.0`, `numpy ≥ 1.26`, `matplotlib ≥ 3.7`.
`requirements.txt` records permissive lower bounds — tighten them to the
exact versions above if you need bit-for-bit reproducibility of the
numbers in the report. (Random-state seeds are set everywhere, but
tiny numeric differences across library versions are possible.)

---

## 4. Installation and running

```bash
# From the Task_5_Ensemble_Learning/ directory:
python -m pip install -r requirements.txt

# Open the notebook:
jupyter notebook Task_5_Ensemble_Learning.ipynb
# then: Kernel → Restart & Run All

# Or run the same pipeline as a plain script:
python pipeline.py
```

The notebook writes figures to `figures/` and tabular/JSON artifacts to
`results/` relative to the working directory.

---

## 5. Models

| Model                           | Role        | Scaling | random_state |
|---------------------------------|-------------|---------|--------------|
| LogisticRegression (max_iter=5000) in a Pipeline with StandardScaler | Baseline    | ✔       | 42 |
| RandomForestClassifier (defaults) | Ensemble    | ✘       | 42 |
| GradientBoostingClassifier (defaults) | Ensemble    | ✘       | 42 |
| RandomForestClassifier (GridSearchCV best params) | Tuned ensemble | ✘       | 42 |

GridSearchCV grid: `n_estimators ∈ {100, 200, 400}`,
`max_depth ∈ {None, 5, 10}`, `min_samples_split ∈ {2, 5}`,
`min_samples_leaf ∈ {1, 2}` — 36 configurations × 5 folds = 180 fits.

---

## 6. Generated results (summary)

See `results/model_comparison.csv` for the full table and the report
PDF for discussion.

| Model                     | Accuracy | Mal. Recall | Mal. F1 | ROC-AUC |
|---------------------------|---------:|------------:|--------:|--------:|
| LogisticRegression        | 0.9825   | 0.9762      | 0.9762  | 0.9954  |
| RandomForest (default)    | 0.9561   | 0.9286      | 0.9398  | 0.9937  |
| GradientBoosting          | 0.9561   | 0.9048      | 0.9383  | 0.9907  |
| RandomForest (optimized)  | 0.9561   | 0.9286      | 0.9398  | 0.9937  |

**Best RF parameters (GridSearchCV):**
`max_depth=None, min_samples_leaf=1, min_samples_split=2, n_estimators=100`
— coincides with the scikit-learn defaults.

**Best CV malignant-F1:** 0.9506 (std 0.0230 across 5 folds).

**Selected model:** Logistic Regression — highest test-set malignant F1
and ROC-AUC, shortest fit time. Random Forest tuning did not improve
test-set performance in this run; this is reported honestly in the
report rather than hidden.

---

## 7. File descriptions

- **`Task_5_Ensemble_Learning.ipynb`** — primary deliverable. Executed from
  a clean kernel; cell outputs are embedded.
- **`Task_5_Ensemble_Learning_Report.pdf`** — 3-page project report.
- **`pipeline.py`** — stand-alone script version of the same pipeline, used
  for CI-style re-execution and for building the notebook. Running it
  reproduces every artifact in `figures/` and `results/`.
- **`figures/*.png`** — all plots generated by the notebook.
- **`results/model_comparison.csv`** — test-set metrics for all four models.
- **`results/random_forest_cv_results.csv`** — full GridSearchCV CV scores.
- **`results/best_parameters.json`** — best Random Forest hyperparameters
  and the associated best CV score (mean and std).
- **`results/final_selection.json`** — final model and the selection
  criterion.
- **`environment_info.txt`** — Python and library versions used during
  execution.

---

## 8. Known limitations

- The test set contains only 114 observations and 42 malignant cases; a
  single misclassification shifts recall by about 2.4 percentage points.
- Only one random seed and one split were used. A fuller study would
  repeat the entire pipeline with multiple seeds to measure stability.
- Impurity-based feature importances reflect how the trees made their
  splits, **not** clinical causation.
- The dataset is a classical research corpus from 1995 and does not
  represent current imaging equipment, protocols or demographics.
- **This project is educational.** It is not a validated clinical
  diagnostic system and must not be used for real medical decisions.
